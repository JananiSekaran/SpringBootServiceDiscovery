package com.microservices.home;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHomeMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
