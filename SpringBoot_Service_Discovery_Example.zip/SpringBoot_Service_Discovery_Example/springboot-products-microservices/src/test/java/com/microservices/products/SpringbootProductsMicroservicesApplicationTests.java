package com.microservices.products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootProductsMicroservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
